package com.example.libri;

public class Transaction {
    private String date, total, cartId;
    private long transID;
    public Transaction(long id, String date, String total, String cartid) {
      transID =id;
      this.date=date;
      this.total=total;
      cartId=cartid;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getTotal() {
        return total;
    }

    public void setTotal(String total) {
        this.total = total;
    }

    public String getCartId() {
        return cartId;
    }

    public void setCartId(String cartId) {
        this.cartId = cartId;
    }

    public long getTransID() {
        return transID;
    }

    public void setTransID(long transID) {
        this.transID = transID;
    }
}
