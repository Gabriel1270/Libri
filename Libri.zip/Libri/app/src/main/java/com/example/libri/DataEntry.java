package com.example.libri;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.PopupMenu;
import android.widget.Toast;

public class DataEntry extends AppCompatActivity implements PopupMenu.OnMenuItemClickListener{
    private Intent intent;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_data_entry);

       ImageView home = findViewById(R.id.libri_logo);
        home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(DataEntry.this,MainActivity.class));
            }
        });

        ImageButton cart = findViewById(R.id.cart_button);
        cart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(DataEntry.this, "Opening cart", Toast.LENGTH_SHORT).show();
            }
        });
    }

    public void showPopUp(View v) {
        PopupMenu popup = new PopupMenu(this, v);
        popup.setOnMenuItemClickListener(this);
        popup.inflate(R.menu.popup_menu);
        popup.show();
    }

    @Override
    public boolean onMenuItemClick(MenuItem menuItem) {
        switch(menuItem.getItemId()){
            case R.id.menu_profile:
                intent = new Intent(this,PrivateProfileView.class);
                startActivity(intent);
                return true;
            case R.id.menu_help:
                Toast.makeText(this, "Help selected", Toast.LENGTH_SHORT).show();
                return true;
            case R.id.menu_messages:
                Toast.makeText(this, "Messages selected", Toast.LENGTH_SHORT).show();
                return true;
            case R.id.menu_logout:
                Toast.makeText(this, "Logout selected", Toast.LENGTH_SHORT).show();
                return true;
            default:
                return false;
        }
    }
}


class UserData{
    private String userNo, email, contactNo, street, suburb, city, ZIP, userName;
    private String password, nameSurname;

    //Default Constructor
    public UserData(){

    }

    public UserData(String email,
                    String contactNo,
                    String street,
                    String suburb,
                    String city,
                    String ZIP,
                    String userName,
                    String password,
                    String nameSurname){

        this.userNo = userNo;
        this.email = email;
        this.contactNo = contactNo;
        this.street = street;
        this.suburb = suburb;
        this.city = city;
        this.ZIP = ZIP;
        this.userName = userName;
        this.password = password;
        this.nameSurname = nameSurname;
    }

    //Setters
    public void setEmail(String email){
        this.email = email;
    }

    public void setContactNo(String contactNo){
        this.contactNo = contactNo;
    }

    public void setStreet(String street){
        this.street = street;
    }

    public void setSuburb(String suburb){
        this.suburb = suburb;
    }

    public void setCity(String city){
        this.city = city;
    }

    public void setZIP(String ZIP){
        this.ZIP = ZIP;
    }

    public void setUserName(String userName){
        this.userName = userName;
    }

    public void setNameSurname(String nameSurname){
        this.nameSurname = nameSurname;
    }
}
