package com.example.libri;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.PopupMenu;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.util.ArrayList;
import java.util.List;

public class Cart extends AppCompatActivity implements PopupMenu.OnMenuItemClickListener{

    private Button checkout;
    private Intent intent;
    private RecyclerView cRecyclerView;
    private CartAdapter cartAdapter;
    private List<CartItem> CartItems;
    private DatabaseReference cDatabaseRef;
    private FirebaseStorage cStorageRef;
    private long cartid =0;
    private double total =0;
    private String booklist ="";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cart);

            ImageView home = findViewById(R.id.libri_logo);
            home.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    startActivity(new Intent(Cart.this, MainActivity.class));
                }
            });


            cRecyclerView = findViewById(R.id.cart);
            cRecyclerView.setHasFixedSize(true);
            cRecyclerView.setLayoutManager(new LinearLayoutManager(this));
            CartItems = new ArrayList<>();
            cartAdapter = new CartAdapter(Cart.this, CartItems);
            cRecyclerView.setAdapter(cartAdapter);

            final ProgressBar ProgressCircle = findViewById(R.id.cart_progress_circle);

            cStorageRef = FirebaseStorage.getInstance();
            cDatabaseRef =  FirebaseDatabase.getInstance().getReference("carts").child("cart "+cartid);//change to retrieve items from cart
            CartItems.clear();
            cDatabaseRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                int count = 0;
                for (DataSnapshot postSnapshot : dataSnapshot.getChildren()) {
                        CartItem cartitem = postSnapshot.getValue(CartItem.class);
                         CartItems.add(cartitem);
                         total += Double.parseDouble(cartitem.getPrice());
                         if (count==dataSnapshot.getChildrenCount()-1){booklist+= cartitem.getTitle();}
                          else{booklist+= cartitem.getTitle()+ ", ";}

                         count++;
                }

                cartAdapter.notifyDataSetChanged();
                ProgressCircle.setVisibility(View.INVISIBLE);
                TextView derived_total = findViewById(R.id.total);

                derived_total.setText("R" + total);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });



        checkout = (Button) findViewById(R.id.but_checkout);
        checkout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                intent = new Intent(Cart.this, Invoice.class);
                intent.putExtra("total", total);
                intent.putExtra("booklist", booklist);
                intent.putExtra("cartno", cartid);
                //intent.putExtra("orderNo", orderNo);
                startActivity(intent);

            }
        });

        ImageButton cart = findViewById(R.id.cart_button);
        cart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(Cart.this, Cart.class));
            }
        });

    }

    public void showPopUp(View v) {
        PopupMenu popup = new PopupMenu(this, v);
        popup.setOnMenuItemClickListener(this);
        popup.inflate(R.menu.popup_menu);
        popup.show();
    }

    @Override
    public boolean onMenuItemClick(MenuItem menuItem) {
        switch(menuItem.getItemId()){
            case R.id.menu_profile:
                intent = new Intent(this,PrivateProfileView.class);
                startActivity(intent);
                return true;
            case R.id.menu_help:
                Toast.makeText(this, "Help selected", Toast.LENGTH_SHORT).show();
                return true;
            case R.id.menu_messages:
                Toast.makeText(this, "Messages selected", Toast.LENGTH_SHORT).show();
                return true;
            case R.id.menu_logout:
                Toast.makeText(this, "Logout selected", Toast.LENGTH_SHORT).show();
                return true;
            default:
                return false;
        }
    }
}
