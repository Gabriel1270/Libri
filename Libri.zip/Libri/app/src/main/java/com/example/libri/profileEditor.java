package com.example.libri;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.PopupMenu;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.List;

public class profileEditor extends AppCompatActivity implements PopupMenu.OnMenuItemClickListener{

    private long userID = 0;
    private DatabaseReference libriDbRef;
    private AdapterView.OnItemClickListener libriDbListener;
    private List<ProfileEdit> edits;
    private ProgressBar progressCircle;
    private Intent intent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile_editor);


        configSaveBtn();

        ImageView home = findViewById(R.id.libri_logo);
        home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(profileEditor.this,MainActivity.class));
            }
        });

        ImageButton cart = findViewById(R.id.cart_button);
        cart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(profileEditor.this, Cart.class));
            }
        });
    }

    private void configSaveBtn(){
        Button save = (Button) findViewById(R.id.saveDataBtn);
        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Code for saving new data here:

                libriDbRef = FirebaseDatabase.getInstance().getReference("User");
                libriDbListener = (AdapterView.OnItemClickListener) libriDbRef.addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        edits.clear();

                        for(DataSnapshot postSnapshot : dataSnapshot.getChildren()){
                            ProfileEdit edit = postSnapshot.getValue(ProfileEdit.class);
                            edit.setEmail(postSnapshot.getKey());
                            edit.setContactNo(postSnapshot.getKey());
                            edit.setStreet(postSnapshot.getKey());
                            edit.setSuburb(postSnapshot.getKey());
                            edit.setCity(postSnapshot.getKey());
                            edit.setZIP(postSnapshot.getKey());
                            edit.setUsername(postSnapshot.getKey());

                            //Password validation
                            try{
                                if(findViewById(R.id.editPasswordTxt) != findViewById(R.id.editConfirmPasswordTxt)){
                                    Toast.makeText(profileEditor.this, "ERROR: Passwords don't match!", Toast.LENGTH_SHORT).show();

                                }else{
                                    edit.setPassword(postSnapshot.getKey());
                                }
                            } catch (Exception e) {
                                e.printStackTrace();
                            }

                            edits.add(edit);
                        }

                        progressCircle.setVisibility(View.INVISIBLE);
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {

                    }
                });

                //Start next activity
                startActivity(new Intent(profileEditor.this, MainActivity.class));
            }
        });
    }

    public void showPopUp(View v) {
        PopupMenu popup = new PopupMenu(this, v);
        popup.setOnMenuItemClickListener(this);
        popup.inflate(R.menu.popup_menu);
        popup.show();
    }

    @Override
    public boolean onMenuItemClick(MenuItem menuItem) {
        switch(menuItem.getItemId()){
            case R.id.menu_profile:
                intent = new Intent(this,PrivateProfileView.class);
                startActivity(intent);
                return true;
            case R.id.menu_help:
                Toast.makeText(this, "Help selected", Toast.LENGTH_SHORT).show();
                return true;
            case R.id.menu_messages:
                Toast.makeText(this, "Messages selected", Toast.LENGTH_SHORT).show();
                return true;
            case R.id.menu_logout:
                Toast.makeText(this, "Logout selected", Toast.LENGTH_SHORT).show();
                return true;
            default:
                return false;
        }
    }
}

