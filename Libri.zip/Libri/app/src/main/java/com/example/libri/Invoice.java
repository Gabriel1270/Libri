package com.example.libri;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.PopupMenu;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.Date;


public class Invoice extends AppCompatActivity implements PopupMenu.OnMenuItemClickListener{

    private Intent intent;
    private long transactionId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_invoice);


        ImageButton cart = findViewById(R.id.cart_button);
        cart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(Invoice.this, Cart.class));
            }
        });


        final String booklist = getIntent().getStringExtra("booklist");
        final double total = getIntent().getDoubleExtra("total",0);
        final String cartid = getIntent().getStringExtra("cartno");

        TextView txtTotal = findViewById(R.id.invoice_total);
        txtTotal.setText("R" + total);

        TextView book = findViewById(R.id.itemname);
        book.setText(booklist);

        Button cont = findViewById(R.id.btn_continue);
        cont.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                final DatabaseReference transRef = FirebaseDatabase.getInstance().getReference("transactions");
                transRef.addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        transactionId = dataSnapshot.getChildrenCount();
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {

                    }
                });

                DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
                Date curDate = new Date();
                String date = dateFormat.format(curDate);
                String tot = Double.toString(total);
                Transaction transaction = new Transaction(transactionId,date,tot,cartid);
                transRef.child(Long.toString(transactionId)).setValue(transaction);

                final DatabaseReference mref = FirebaseDatabase.getInstance().getReference("adverts");
                final DatabaseReference cref = FirebaseDatabase.getInstance().getReference("carts");

                mref.addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        for(DataSnapshot postsnapshot: dataSnapshot.getChildren()){
                          

                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {

                    }
                });
                cref.addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        for(DataSnapshot postsnapshot: dataSnapshot.getChildren()){
                            CartItem ci = postsnapshot.getValue(CartItem.class);
                            if(cartid.equals(ci.getCartid())){
                             cref.removeValue();

                            }

                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {

                    }
                });

                intent = new Intent(Invoice.this, Receipt.class);
                intent.putExtra("total", total);
                intent.putExtra("booklist", booklist);
                startActivity(intent);
            }
        });

    }


    public void showPopUp(View v) {
        PopupMenu popup = new PopupMenu(this, v);
        popup.setOnMenuItemClickListener(this);
        popup.inflate(R.menu.popup_menu);
        popup.show();
    }

    @Override
    public boolean onMenuItemClick(MenuItem menuItem) {
        switch(menuItem.getItemId()){
            case R.id.menu_profile:
                intent = new Intent(this,PrivateProfileView.class);
                startActivity(intent);
                return true;
            case R.id.menu_help:
                Toast.makeText(this, "Help selected", Toast.LENGTH_SHORT).show();
                return true;
            case R.id.menu_messages:
                Toast.makeText(this, "Messages selected", Toast.LENGTH_SHORT).show();
                return true;
            case R.id.menu_logout:
                Toast.makeText(this, "Logout selected", Toast.LENGTH_SHORT).show();
                return true;
            default:
                return false;
        }
    }

}
