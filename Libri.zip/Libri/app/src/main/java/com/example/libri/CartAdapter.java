package com.example.libri;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.List;

public class CartAdapter extends RecyclerView.Adapter<CartAdapter.ImageViewHolder> {
    private Context mContext;
    private List<CartItem> CartItem;

    public CartAdapter(Context context, List<CartItem> cartItems) {
        mContext = context;
        CartItem = cartItems;
    }

    @NonNull
    @Override
    public ImageViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(mContext).inflate(R.layout.cartitem, parent, false);
        return new ImageViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull ImageViewHolder holder, final int position) {
        final CartItem cart = CartItem.get(position);
        final long itemid  = cart.getItemid();

        final String ad_id = cart.getAd_id();
        final long cartid = cart.getCartid();
        holder.cart_title.setText(cart.getTitle());
        holder.cart_quantity.setText(cart.getQuantity());
        holder.cart_price.setText("R"+ cart.getPrice());
        // holder.ad_image.setImageURI(Uri.parse(uploadCurrent.getImageURL()))); native

      /*  Picasso.with(mContext)
                .load("")
                .placeholder(R.mipmap.ic_launcher)
                .fit()
                // .centerCrop()
                .into(holder.book_image);*/

      holder.cart_remove.setOnClickListener(new View.OnClickListener() {
          @Override
          public void onClick(View view) {
             Toast.makeText(mContext, "removing item", Toast.LENGTH_SHORT).show();
              final DatabaseReference cref = FirebaseDatabase.getInstance().getReference("carts").child("cart "+cartid);
              cref.addListenerForSingleValueEvent(new ValueEventListener() {
                  @Override
                  public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                      cref.child(Long.toString(itemid)).removeValue();
                  }

                  @Override
                  public void onCancelled(@NonNull DatabaseError databaseError) {

                  }
              });
              final DatabaseReference dref = FirebaseDatabase.getInstance().getReference("adverts");
              dref.addListenerForSingleValueEvent(new ValueEventListener() { // change ad status to on hold when in cart
                  @Override
                  public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                      try{
                          for (DataSnapshot postSnapshot : dataSnapshot.getChildren()){
                              Upload upload = postSnapshot.getValue(Upload.class);
                              if(ad_id.equals(upload.getId())){
                                  upload.setStatus("Available");
                                  dref.child(ad_id).setValue(upload);


                              }
                          }}catch (Exception e){
                          Toast.makeText(mContext, "" + e, Toast.LENGTH_LONG).show();
                      }
                      mContext.startActivity(new Intent(mContext, Cart.class));
                  }

                  @Override
                  public void onCancelled(@NonNull DatabaseError databaseError) {
                      Toast.makeText(mContext, "Failed", Toast.LENGTH_SHORT).show();
                  }
              });


          }
      });


      holder.cart_title.setOnClickListener(new View.OnClickListener() {
          @Override
          public void onClick(View view) {
              final DatabaseReference dref = FirebaseDatabase.getInstance().getReference("adverts");
              dref.addListenerForSingleValueEvent(new ValueEventListener() {
                  @Override
                  public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                      for (DataSnapshot postSnapshot : dataSnapshot.getChildren()) {
                          Upload uploadCurrent = postSnapshot.getValue(Upload.class);
                          if(ad_id.equals(uploadCurrent.getId())) {
                              Intent intent = new Intent(mContext, View_ad.class);
                              intent.putExtra("ad_id", uploadCurrent.getId());
                              intent.putExtra("title", uploadCurrent.getTitle());
                              intent.putExtra("author", uploadCurrent.getAuthor());
                              intent.putExtra("status", uploadCurrent.getStatus());
                              intent.putExtra("condition", uploadCurrent.getCondition());
                              //intent.putExtra("seller", uploadCurrent.getSeller());
                              intent.putExtra("price", uploadCurrent.getPrice());
                              intent.putExtra("date", uploadCurrent.getDate());
                              intent.putExtra("image", uploadCurrent.getImageURL());
                              mContext.startActivity(intent);
                          }
                      }
                  }

                  @Override
                  public void onCancelled(@NonNull DatabaseError databaseError) {

                  }
              });



          }
      });
    }

    @Override
    public int getItemCount() {
        return CartItem.size();
    }


    public class ImageViewHolder extends RecyclerView.ViewHolder {
        public TextView cart_title, cart_price, cart_quantity, cart_remove;
        public RelativeLayout cart;
        public ImageView book_image;


        public ImageViewHolder(@NonNull View itemView) {
            super(itemView);

            cart_title = itemView.findViewById(R.id.cart_book_title);
            cart_price = itemView.findViewById(R.id.cart_book_price);
            cart_quantity = itemView.findViewById(R.id.cart_book_quantity);
            cart = itemView.findViewById(R.id.cart);
            book_image = itemView.findViewById(R.id.cart_book_image);
            cart_remove = itemView.findViewById(R.id.cart_book_remove_btn);
        }
    }
}
